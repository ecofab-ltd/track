#
# TABLE STRUCTURE FOR: tb_brand
#

DROP TABLE IF EXISTS `tb_brand`;

CREATE TABLE `tb_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=Active, 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tb_brand` (`id`, `brand`, `status`) VALUES (1, 'BMA', 1);
INSERT INTO `tb_brand` (`id`, `brand`, `status`) VALUES (2, 'BMS', 1);
INSERT INTO `tb_brand` (`id`, `brand`, `status`) VALUES (3, 'OLYMP', 1);
INSERT INTO `tb_brand` (`id`, `brand`, `status`) VALUES (4, 'BMB', 1);
INSERT INTO `tb_brand` (`id`, `brand`, `status`) VALUES (5, 'M&S T11', 1);


#
# TABLE STRUCTURE FOR: tb_daily_cut
#

DROP TABLE IF EXISTS `tb_daily_cut`;

CREATE TABLE `tb_daily_cut` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `operation_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `size_set_cut_qty` int(11) NOT NULL,
  `trial_cut_qty` int(11) NOT NULL,
  `bulk_cut_qty` int(11) NOT NULL,
  `package_ready_qty` int(11) NOT NULL,
  `inserted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_daily_finishing
#

DROP TABLE IF EXISTS `tb_daily_finishing`;

CREATE TABLE `tb_daily_finishing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `operation_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `unit_id` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `wash_send_qty` int(11) NOT NULL,
  `wash_receive_qty` int(11) NOT NULL,
  `embroidery_send_qty` int(11) NOT NULL,
  `embroidery_receive_qty` int(11) NOT NULL,
  `print_send_qty` int(11) NOT NULL,
  `print_receive_qty` int(11) NOT NULL,
  `poly_qty` int(11) NOT NULL,
  `carton_qty` int(11) NOT NULL,
  `ship_qty` int(11) NOT NULL,
  `inserted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_daily_sew
#

DROP TABLE IF EXISTS `tb_daily_sew`;

CREATE TABLE `tb_daily_sew` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `operation_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `unit_id` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  `line_input` int(11) NOT NULL,
  `sew_qty` int(11) NOT NULL,
  `inserted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_floor_assign
#

DROP TABLE IF EXISTS `tb_floor_assign`;

CREATE TABLE `tb_floor_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `floor_quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_line_assign
#

DROP TABLE IF EXISTS `tb_line_assign`;

CREATE TABLE `tb_line_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  `line_quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_order
#

DROP TABLE IF EXISTS `tb_order`;

CREATE TABLE `tb_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `purchase_order` varchar(255) NOT NULL,
  `item` varchar(255) NOT NULL,
  `quality` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `style_no` varchar(255) NOT NULL,
  `style_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `ex_factory_date` date NOT NULL,
  `upload_date` date NOT NULL,
  `upload_by` int(11) NOT NULL,
  `update_date` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `upload_unit_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_order_module_control
#

DROP TABLE IF EXISTS `tb_order_module_control`;

CREATE TABLE `tb_order_module_control` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tb_order_module_control` (`id`, `unit_id`, `user_id`, `username`) VALUES (2, 2, 3, 'sd_1');
INSERT INTO `tb_order_module_control` (`id`, `unit_id`, `user_id`, `username`) VALUES (3, 3, 3, 'sd_1');


#
# TABLE STRUCTURE FOR: tb_order_summary
#

DROP TABLE IF EXISTS `tb_order_summary`;

CREATE TABLE `tb_order_summary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `cut_qty` int(11) NOT NULL,
  `package_ready_qty` int(11) NOT NULL,
  `line_input_qty` int(11) NOT NULL,
  `line_output_qty` int(11) NOT NULL,
  `poly_qty` int(11) NOT NULL,
  `carton_qty` int(11) NOT NULL,
  `wash_send_qty` int(11) NOT NULL,
  `wash_receive_qty` int(11) NOT NULL,
  `embroidery_send_qty` int(11) NOT NULL,
  `embroidery_receive_qty` int(11) NOT NULL,
  `print_send_qty` int(11) NOT NULL,
  `print_receive_qty` int(11) NOT NULL,
  `ship_qty` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tb_unit
#

DROP TABLE IF EXISTS `tb_unit`;

CREATE TABLE `tb_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `unit_order_code_start_no` int(11) NOT NULL,
  `unit_order_code_max_no` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=Active, 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (1, 'ISML-1', 'ISML-1', 100000000, 100000003, 0, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (2, 'ISML-2', 'ISML-2', 200000000, 200000000, 0, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (3, 'ECOFAB', 'ECOFAB', 300000000, 300000000, 0, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (4, 'FLOOR-1', 'FLOOR-1', 0, 0, 1, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (5, 'FLOOR-2', 'FLOOR-2', 0, 0, 1, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (6, 'LINE-1', '1', 0, 0, 1, 4, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (7, 'LINE-2', '2', 0, 0, 1, 4, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (8, 'LINE-3', '3', 0, 0, 1, 4, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (9, 'LINE-4', '4', 0, 0, 1, 4, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (10, 'LINE-5', '5', 0, 0, 1, 4, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (11, 'LINE-6', '6', 0, 0, 1, 4, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (12, 'LINE-7', '7', 0, 0, 1, 5, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (13, 'LINE-8', '8', 0, 0, 1, 5, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (14, 'LINE-9', '9', 0, 0, 1, 5, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (15, 'LINE-10', '10', 0, 0, 1, 5, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (16, 'LINE-11', '11', 0, 0, 1, 5, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (17, 'LINE-12', '12', 0, 0, 1, 5, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (18, 'GROUND FLOOR', 'GROUND FLOOR', 0, 0, 3, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (19, 'FLOOR-1', 'FLOOR-1', 0, 0, 3, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (20, 'FLOOR-2', 'FLOOR-2', 0, 0, 3, 0, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (21, 'LINE-1', '1', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (22, 'LINE-2', '2', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (23, 'LINE-3', '3', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (24, 'LINE-4', '4', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (25, 'LINE-5', '5', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (26, 'LINE-6', '6', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (27, 'LINE-7', '7', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (28, 'LINE-8', '8', 0, 0, 3, 20, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (29, 'LINE-9', '9', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (30, 'LINE-10', '10', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (31, 'LINE-11', '11', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (32, 'LINE-12', '12', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (33, 'LINE-13', '13', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (34, 'LINE-14', '14', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (35, 'LINE-15', '15', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (36, 'LINE-16', '16', 0, 0, 3, 19, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (37, 'LINE-17', '17', 0, 0, 3, 18, 1);
INSERT INTO `tb_unit` (`id`, `name`, `code`, `unit_order_code_start_no`, `unit_order_code_max_no`, `unit_id`, `floor_id`, `status`) VALUES (38, 'LINE-18', '18', 0, 0, 3, 18, 1);


#
# TABLE STRUCTURE FOR: tb_user
#

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `access_level` int(11) NOT NULL COMMENT '0=Administrator, 1=Unit Planner, 2=SD, 3=Floor Planner, 4=Cutting MIS, 5=Floor MIS',
  `unit_id` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=Active, 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (1, 'administrator', '1212', 0, 0, 0, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (2, 'isml_plan', '1212', 1, 1, 0, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (3, 'sd_1', '1212', 2, 0, 0, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (4, 'sd_2', '1212', 2, 0, 0, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (5, 'plan_floor_1', '1212', 3, 1, 4, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (6, 'sd_3', '1212', 2, 0, 0, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (7, 'plan_floor_2', '1212', 3, 1, 5, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (8, 'cutting_mis', '1212', 4, 1, 0, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (9, 'floor_mis_1', '1212', 5, 1, 4, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (10, 'floor_mis_2', '1212', 5, 1, 5, 1);
INSERT INTO `tb_user` (`id`, `username`, `password`, `access_level`, `unit_id`, `floor_id`, `status`) VALUES (11, 'Ecofab_plan', '1212', 1, 3, 0, 1);


#
# TABLE STRUCTURE FOR: tb_user_brand_assign
#

DROP TABLE IF EXISTS `tb_user_brand_assign`;

CREATE TABLE `tb_user_brand_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tb_user_brand_assign` (`id`, `user_id`, `brand_id`) VALUES (1, 3, 5);


